package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AMOLED Black & Midnight Dark Palette
val AmoledBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF0D1017)
val DarkSurfaceVariant = Color(0xFF141923)
val DarkSurfaceContainer = Color(0xFF1A202C)
val DarkSurfaceContainerHigh = Color(0xFF222A3A)

// Accents
val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B4D8)
val CyanAccentGlow = Color(0x3300E5FF)

val IndigoAccent = Color(0xFF6366F1)
val EmeraldBreak = Color(0xFF10B981)
val EmeraldBreakGlow = Color(0x3310B981)
val CoralWarning = Color(0xFFEF4444)

// Text
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Borders
val BorderSubtle = Color(0xFF232D3F)
val BorderHighlight = Color(0xFF334155)
